Download and extract the Ubuntu Dialogue Corpus dataset here:

Source: http://cs.mcgill.ca/~jpineau/datasets/ubuntu-corpus-1.0/

```bash
# From this directory:
wget http://cs.mcgill.ca/~jpineau/datasets/ubuntu-corpus-1.0/ubuntu_dialogs.tgz && tar -xvzf ubuntu_dialogs.tgz && rm ubuntu_dialogs.tgz
```

Individual conversation files will be located in a `dialogs/` subdirectory.
